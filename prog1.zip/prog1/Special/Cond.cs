// Cond -- Parse tree node strategy for printing the special form cond

using System;

namespace Tree
{
    public class Cond : Special
    {
        // TODO: Add any fields needed.
        public int IndentationInt;
        public string IndentationString;

        // TODO: Add an appropriate constructor.
        public Cond()
        {
           
        }

        public override void print(Node t, int n, bool p)
        { 
            // TODO: Implement this function.
        }
    }
}


